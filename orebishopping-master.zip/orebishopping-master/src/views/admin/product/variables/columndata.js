export const ColumnDataImageThumnail = [
  {
    Header: "Image Thumnail",
    accessor: "imgThumnail",
  },
  {
    Header: "Product name",
    accessor: "productName",
  },
  {
    Header: "Action",
    accessor: "action",
  },
];
