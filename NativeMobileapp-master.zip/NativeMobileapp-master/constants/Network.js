export default network = {
  serverip: "http://192.168.202.71:3000",
};
