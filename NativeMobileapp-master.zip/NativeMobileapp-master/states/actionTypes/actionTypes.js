export const CART_ADD = "addtocart";
export const CART_REMOVE = "removefromcart";
export const INCREASE_CART_ITEM_QUANTITY = "inceasequantity";
export const DECREASE_CART_ITEM_QUANTITY = "deceasequantity";
export const EMPTY_CART = "emptycart";
