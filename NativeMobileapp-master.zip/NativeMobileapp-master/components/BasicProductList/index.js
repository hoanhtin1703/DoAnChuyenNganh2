export { default } from "./BasicProductList";
