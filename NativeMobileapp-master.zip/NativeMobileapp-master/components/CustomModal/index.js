export { default } from "./CustomModal";
