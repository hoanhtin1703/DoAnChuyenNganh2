export { default } from "./UserProfileCard";
