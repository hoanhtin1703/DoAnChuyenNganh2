export { default } from "./CategoryList";
