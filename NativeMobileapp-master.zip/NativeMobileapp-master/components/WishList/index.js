export { default } from "./WishList";
